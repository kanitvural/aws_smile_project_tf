import json
import boto3
from botocore.exceptions import ClientError


ses = boto3.client('ses', region_name='eu-west-2')
email_address = 'kanitvural@gmail.com'  # Admin e-maili

def send_verification_email():
    response = ses.verify_email_identity(EmailAddress=email_address)
    print(f"Verification email sent to {email_address}. Response: {response}")

def send_notification_email(firstname, lastname):
    subject = "New entry notification"
    body_text = f"{firstname} {lastname} has entered the company."
    try:
        response = ses.send_email(
            Source=email_address,
            Destination={
                'ToAddresses': [email_address],
            },
            Message={
                'Subject': {
                    'Data': subject
                },
                'Body': {
                    'Text': {
                        'Data': body_text
                    }
                }
            }
        )
        print(f"Notification email sent to {email_address}. Response: {response}")
    except ClientError as e:
        print(f"Error sending email: {e}")
        raise

def lambda_handler(event, context):
    body = json.loads(event.get('body', '{}'))
    firstname = body.get('firstname', 'Unknown')
    lastname = body.get('lastname', 'Unknown')


    response = ses.list_identities(IdentityType='EmailAddress')
    if email_address not in response['Identities']:
        send_verification_email()
        return {
            'statusCode': 200,
            'body': json.dumps('Verification email sent.')
        }
    

    send_notification_email(firstname, lastname)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Notification email sent.')
    }
