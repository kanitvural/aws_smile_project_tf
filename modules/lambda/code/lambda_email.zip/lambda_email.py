import json
import boto3
from botocore.exceptions import ClientError


ses = boto3.client('ses', region_name='eu-west-2')
email_address = 'kanitvural@gmail.com'  # Admin e-maili

def send_verification_email():
    response = ses.verify_email_identity(EmailAddress=email_address)
    print(f"Verification email sent to {email_address}. Response: {response}")

def send_notification_email(firstname, lastname):
    subject = "Yeni Giriş Bildirimi"
    body_text = f"{firstname} {lastname} şirkete giriş yaptı."
    try:
        response = ses.send_email(
            Source=email_address,
            Destination={
                'ToAddresses': [email_address],
            },
            Message={
                'Subject': {
                    'Data': subject
                },
                'Body': {
                    'Text': {
                        'Data': body_text
                    }
                }
            }
        )
        print(f"Notification email sent to {email_address}. Response: {response}")
    except ClientError as e:
        print(f"Error sending email: {e}")
        raise

def lambda_handler(event, context):
    body = json.loads(event.get('body', '{}'))
    firstname = body.get('firstname', 'Unknown')
    lastname = body.get('lastname', 'Unknown')


    response = ses.list_identities(IdentityType='EmailAddress')
    if email_address not in response['Identities']:
        send_verification_email()
        return {
            'statusCode': 200,
            'body': json.dumps('Verification email sent.')
        }
    

    send_notification_email(firstname, lastname)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Notification email sent.')
    }


# import json
# import boto3
# from botocore.exceptions import ClientError

# # Initialize AWS SES and SQS clients
# ses_client = boto3.client('ses', region_name='eu-west-2')
# sqs_client = boto3.client('sqs', region_name='eu-west-2')

# # Define your admin email and SQS queue URL
# admin_email = "kanitvural@gmail.com"
# sqs_queue_url = 'https://sqs.eu-west-2.amazonaws.com/058264126563/email_queue'  # Replace with your SQS queue URL

# def send_verification_email():
#     try:
#         response = ses_client.verify_email_identity(EmailAddress=admin_email)
#         return response
#     except ClientError as e:
#         print(e.response['Error']['Message'])
#         return None

# def lambda_handler(event, context):
#     body = json.loads(event.get('body', '{}'))
#     first_name = body.get('firstname')
#     last_name = body.get('lastname')
    
#     if not first_name or not last_name:
#         return {
#             'statusCode': 400,
#             'body': json.dumps('Invalid request. "firstname" and "lastname" are required.')
#         }
    
#     # Check if the email is already verified
#     response = ses_client.get_identity_verification_attributes(Identities=[admin_email])
#     verification_status = response['VerificationAttributes'].get(admin_email, {}).get('VerificationStatus', 'Not Verified')
    
#     if verification_status == 'Success':
#         # If verified, send message to SQS
#         send_sqs_message(first_name, last_name)
#         return {
#             'statusCode': 200,
#             'body': json.dumps('Verification completed and message sent to SQS.')
#         }
#     else:
#         # If not verified, initiate verification
#         send_verification_email()
#         return {
#             'statusCode': 200,
#             'body': json.dumps('Verification email sent. Please verify your email address.')
#         }

# def send_sqs_message(first_name, last_name):
#     message_body = json.dumps({
#         'first_name': first_name,
#         'last_name': last_name
#     })
    
#     try:
#         response = sqs_client.send_message(
#             QueueUrl=sqs_queue_url,
#             MessageBody=message_body
#         )
#         return response
#     except ClientError as e:
#         print(e.response['Error']['Message'])
#         return None

