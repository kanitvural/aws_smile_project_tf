import json
import boto3

def lambda_handler(event, context):
    rekognition_client = boto3.client('rekognition')
    
    body = json.loads(event.get('body', '{}'))
    image_key = body.get("image_key")
    
    s3_bucket = 'kntbucketlondon'
    
            
    image = {
        'S3Object': {
            'Bucket': s3_bucket,
            'Name':  f'smile/{image_key}'
        }
    }
    
    try:
        response = rekognition_client.detect_faces(
            Image=image,
            Attributes=['ALL']
        )
        
        face_details = response.get('FaceDetails', [])
        
        if face_details:
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'FaceDetails': face_details
                })
            }
        else:
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'Message': 'No faces detected.'
                })
            }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }
