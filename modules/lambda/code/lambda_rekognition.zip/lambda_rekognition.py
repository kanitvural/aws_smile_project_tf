import json
import boto3

def lambda_handler(event, context):
    
    rekognition_client = boto3.client('rekognition')

    body = json.loads(event.get('body', '{}'))
    target_image = body.get("target_image")
    source_images = body.get("source_images", [])
    
    results = []
    
    for source_image in source_images:
        
        SourceImage = {
            'S3Object': {
                'Bucket': 'kntbucketlondon',
                'Name': f'archive/{source_image}'
            }
        }
        
        TargetImage = {
            'S3Object': {
                'Bucket': 'kntbucketlondon',
                'Name': f'smile/{target_image}'
            }
        }
        
        similarity_threshold = 90
        
        try:
            response = rekognition_client.compare_faces(
                SourceImage=SourceImage,
                TargetImage=TargetImage,
                SimilarityThreshold=similarity_threshold
            )
            
            face_matches = response['FaceMatches']
            
            for match in face_matches:
                similarity = match['Similarity']
                if similarity >= 90:
                    
                    results.append({
                        'Similarity': similarity,
                        'SourceImage': source_image
                    })
                    
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'error': str(e)
                })
            }
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'Matches': results,
            'UnmatchedFaces': response.get('UnmatchedFaces', [])
        })
    }

