import json
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timezone


dynamodb = boto3.client('dynamodb', region_name='eu-west-2') 

def lambda_handler(event, context):
    print('Received event:', json.dumps(event))  
    table_name = 'smile'
    body = json.loads(event.get('body', '{}'))
    
    try:
 
        try:
            response = dynamodb.describe_table(TableName=table_name)
            table_status = response['Table']['TableStatus']
            
            if table_status == 'ACTIVE':
                print('Table already exists and is active')
                
            else:
                print(f'Table exists but is not active, status: {table_status}')
                
        except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceNotFoundException':
                
                try:
                    dynamodb.create_table(
                        TableName=table_name,
                        KeySchema=[
                            {
                                'AttributeName': 'id',
                                'KeyType': 'HASH'  # Partition key
                            }
                        ],
                        AttributeDefinitions=[
                            {
                                'AttributeName': 'id',
                                'AttributeType': 'S'
                            }
                        ],
                        ProvisionedThroughput={
                            'ReadCapacityUnits': 5,  
                            'WriteCapacityUnits': 5  
                        }
                    )
                    print('Table created successfully with provisioned capacity')
                    
                    
                    print('Waiting for table to become active...')
                    waiter = dynamodb.get_waiter('table_exists')
                    waiter.wait(TableName=table_name)
                    print('Table is active now.')
                    
                except ClientError as e:
                    return {
                        'statusCode': 500,
                        'body': json.dumps(f'Error creating table: {e}')
                    }
                    
            else:
                return {
                    'statusCode': 500,
                    'body': json.dumps(f'Error describing table: {e}')
                }
        
    
        try:
            
            current_time = datetime.now(timezone.utc).strftime('%d/%m/%Y/%H:%M:%S')
            item_id = current_time.replace('/', '').replace(':', '') 
            
            firstname = body.get('firstname', 'Unknown')
            lastname = body.get('lastname', 'Unknown')
            image_url = body.get('image_url', 'No URL')
            
            print(f'Firstname: {firstname}, Lastname: {lastname}, Image URL: {image_url}') 
            
          
            dynamodb.put_item(
                TableName=table_name,
                Item={
                    'id': {'S': item_id},
                    'firstname': {'S': firstname},
                    'lastname': {'S': lastname},
                    'time': {'S': current_time},
                    'image_url': {'S': image_url}
                }
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps('Item added successfully')
            }
            
        except ClientError as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f'Error adding item: {e}')
            }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Unexpected error: {e}')
        }
